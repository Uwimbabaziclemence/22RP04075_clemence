<?php
include('connection.php');
if(isset($_GET['id']))
{
    $id=$_GET['id'];
    $delete="DELETE FROM student WHERE id='$id'";
    $query=mysqli_query($connection,$delete);
    if($query)
    {
        echo"<script>alert('Student Deeleted Well');</script>";
    }
}
header("location:retrieve.php");
?>