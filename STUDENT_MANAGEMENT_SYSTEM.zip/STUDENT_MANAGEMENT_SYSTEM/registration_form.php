<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registratio form</title>
    <style>
   body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
                font-size: 30px;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
        }
        .form
        {
            margin-top: 50px;
            }
            .form input[type="submit"] {
                background-color: #4CAF50;
                color: white;
                border-radius: 10px;;
                border: none;
                font-size: 30px;
            }

    </style>
</head>
<body>
    <center><div class='form'>
        <form action="" method="POST">
            <h2>Student Registration Form</h2>
            <p>First Name: <input type="text" name="first_name" placeholder="Enter First Name"></p>
            <p>Last NAme: <input type="text" name="last_name" placeholder="Enter Last Name"></p>
            <p>Date of Birth: <input type="date" name="date_of_birth"></p>
            <p>Gender: <input type="radio" name="gender" value="M">Male  <input type="radio" name="gender" value="F">Female</p>
            <p>Clas: <input type="text" name="class" placeholder="Enter Your Class"></p>
            <p>Contact_info: <input type="number" name="contact_number" placeholder="Enter Phone Number"></p>
            <p>Email: <input type="email" name="email" placeholder="Enter your Email"></p>
            <p>Address: <input type="text" name="address" placeholder="Enter Your Address"></p>
            <p><input type="submit" name="submit" value="Submit">&nbsp;&nbsp; <input type="reset" name="reset" value="Clear" 
            style=" background-color: #4CAF50;color: white; border-radius: 10px;border: none;font-size: 30px;"></p>
        </form></div>
        <?php
        include('connection.php');
        if(isset($_POST['submit']))
        {
            $fname=$_POST['first_name'];
            $lname=$_POST['last_name'];
            $date=$_POST['date_of_birth'];
            $gender=$_POST['gender'];
            $class=$_POST['class'];
            $contact=$_POST['contact_number'];
            $email=$_POST['email'];
            $address=$_POST['address'];
if(empty($fname) && empty($lname) && empty($date) && empty($gender) && empty($class) && empty($contact) && empty($email) && empty($address))
{
    echo"All Fields Are Required to Continue"; 
}
else
{

    $insert="INSERT INTO student(first_name,last_name,date_of_birth,gender,class,contact_number,email,address) VALUES('$fname','$lname','$date',' $gender','$class','$contact','$email','$address')";
    $insertquery=mysqli_query($connection,$insert);

    if($insertquery == true)
    {

        echo"<script> alert('New Student's Information recorded'); </script>";
        header("location:retrieve.php");
    }
    else
    {
        echo "<script> alert('Failed to record id'); </script>";
    }

}
}
        ?>
    </center>
</body>
</html>