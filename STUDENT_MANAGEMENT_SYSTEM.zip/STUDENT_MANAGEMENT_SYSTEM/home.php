<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            font-size: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .link {
            display: flex;
            padding: 100px;
            font-size: 50px;
            border: 10px black;
        }
        a {
            text-decoration: none;
            margin: 0 15px;
        }
    </style>
</head>
<body><center>
    <div class="dashboard">
        <h1>Welcome</h1>
        <div class="link">
            <a href="registration_form.php">Add New Student</a>
            <a href="retrieve.php">View Information</a>
            <a href="logout.php">Logout</a>
        </div>
    </div></center>
</body>
</html>