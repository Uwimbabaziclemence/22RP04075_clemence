<?php 
session_start();
if($_SESSION['username']);
{
    header("location:home.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>


    <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .login-form {
                background-color: #fff;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                width: 300px;
                text-align: center;

            }
            .login-form input {
                width: 100%;
                padding: 10px;
                margin: 10px 0;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 16px;
            }
            .login-form input[type="submit"] {
                background-color: #4CAF50;
                color: white;
                border: none;
            }
            .message {
                color: red;
                margin-top: 10px;
            }
        </style>
    
</head>
<body>
    <center>
        <div class="login-form"><form action="" method="POST">
            <h1>Login Form</h1>
<div style="color:red;">
            <?php
    include('connection.php');

    if(isset($_POST['submit']))
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        if(empty($username) && empty($password))
        {
            echo "Please All fields are required";
        }
        else
        {
            $select="SELECT * FROM users WHERE username='$username' AND password='$password'";
            $query=mysqli_query($connection,$select);

            if(mysqli_num_rows($query)>0)
            {
                $_SESSION['username']=$username;

                $userinfo=[
                    "username"=>$row['username'],"password"=>$row['password']];
                setcookie('user',serialize($userinfo),time() + 3600,'/');
                header("location:home.php");
            }
            else
            {
                echo "<script> alert('Incorrect Username Or Password'); </script>";
            }
        }
    }
    ?>
</div>
            <p>User Name: <input type="text" name="username" placeholder="Enter Username"></p>
            <p>Password: <input type="password" name="password" placeholder="Enter your password"></p>
            <p><input type="submit" name="submit" value="login"></p>
        </form></div>
    </center>
</body>
</html>