<?php
include('connection.php');
$id = $_GET['id']; // Get the ID from the URL

// Fetch the existing data to populate the form
$select = "SELECT * FROM student WHERE id='$id'";
$results = mysqli_query($connection, $select);
$fetch = mysqli_fetch_array($results); // Fetch the data once

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Collect updated data from the form
        $fname = $_POST['first_name'];
        $lname = $_POST['last_name'];
        $date = $_POST['date_of_birth'];
        $gender = $_POST['gender']; // Corrected this line to use 'gender'
        $class = $_POST['class'];   // Added this line to use 'class'
        $contact = $_POST['contact_number'];
        $email = $_POST['email'];
        $address = $_POST['address'];

        // Update query
        $update = "UPDATE student SET 
            first_name='$fname',
            last_name='$lname',
            date_of_birth='$date',
            gender='$gender',
            class='$class', 
            contact_number='$contact',
            email='$email',
            address='$address' 
            WHERE id='$id'";

        $update1 = mysqli_query($connection, $update);

        if ($update1) {
            echo "<script>alert('Update Successful!');</script>";
            header("Location: retrieve.php");
            exit(); // Stop executing after the redirect
        } else {
            echo "<script>alert('Failed to update student!');</script>";
            header("Location: retrieve.php");
            exit(); // Stop executing after the redirect
        }
    } catch (Exception $error) {
        echo "Error: " . $error->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Form</title>
</head>
<body>
<form action="" method="POST">
    <h2>Updating Registration Form</h2>

    <p><input type="hidden" name="id"></p>
    <p>First Name: <input type="text" name="first_name" value="<?php echo $fetch['first_name']; ?>"></p>
    <p>Last Name: <input type="text" name="last_name" value="<?php echo $fetch['last_name']; ?>"></p>
    <p>Date of Birth: <input type="date" name="date_of_birth" value="<?php echo $fetch['date_of_birth']; ?>"></p>
    <p>Gender: <input type="text" name="gender" value="<?php echo $fetch['gender']; ?>"></p>
    <p>Class: <input type="text" name="class" value="<?php echo $fetch['class']; ?>"></p>
    <p>Contact Info: <input type="number" name="contact_number" value="<?php echo $fetch['contact_number']; ?>"></p>
    <p>Email: <input type="email" name="email" value="<?php echo $fetch['email']; ?>"></p>
    <p>Address: <input type="text" name="address" value="<?php echo $fetch['address']; ?>"></p>
    <p><input type="submit" name="submit" value="Submit">&nbsp;&nbsp;<input type="reset" name="reset" value="Clear"></p>
</form>
</body>
</html>